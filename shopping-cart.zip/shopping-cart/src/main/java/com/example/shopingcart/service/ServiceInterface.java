package com.example.shopingcart.service;

import com.example.shopingcart.model.User;

public interface ServiceInterface {
	
	public User login(String username, String password);
	
	public String addUser(User user);

}
