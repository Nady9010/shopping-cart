package com.example.shopingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopingcart.model.User;
import com.example.shopingcart.service.ServiceInterface;

@RestController
public class UserController {
	
	@Autowired
	private ServiceInterface serviceInterface;
	
	@GetMapping("/login/{userName}/{password}")
	public User login(@PathVariable String username, @PathVariable String password) {
		User user=serviceInterface.login(username, password);
		if(user==null)
			return new User();
		else 
			return user;
		
	}
	
	@PostMapping("/addUser")
	public int addUser(@RequestBody User user) {
		return 0;
	}

}
